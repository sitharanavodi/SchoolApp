package com.manage.school.controaler;

import org.springframework.stereotype.Controller;

@Controller
public class ParentsCon {
}
