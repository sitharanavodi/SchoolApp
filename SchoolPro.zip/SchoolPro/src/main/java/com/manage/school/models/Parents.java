package com.manage.school.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Parents {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ID;
    private String MotherName;
    private String FartherName;
    private String PAddress;
    private String PTP;

    public Parents(String motherName, String fartherName, String Paddress, String PTP) {
        MotherName = motherName;
        FartherName = fartherName;
        PAddress = Paddress;
        this.PTP = PTP;
    }

    public Parents() {
    }

    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }

    public String getMotherName() {
        return MotherName;
    }

    public void setMotherName(String motherName) {
        MotherName = motherName;
    }

    public String getFartherName() {
        return FartherName;
    }

    public void setFartherName(String fartherName) {
        FartherName = fartherName;
    }

    public String getAddress() {
        return PAddress;
    }

    public void setAddress(String paddress) {
        PAddress = paddress;
    }

    public String getTP() {
        return PTP;
    }

    public void setTP(String pTP) {
        this.PTP = pTP;
    }



}
